// prevent including extmod/virtpin.h
#define mp_hal_pin_obj_t
